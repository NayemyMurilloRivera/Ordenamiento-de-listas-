#include <iostream>
using namespace std;
template<class t, int n=10>

struct pila {
    int n1;
    t * arrpr;
    t * top;
    pila();
    ~pila();
    bool lleno();// 
    bool vacio();
    bool push(t val);
    bool pop(t & val);
};

template<class t, int n>
pila<t,n>::pila() {
    n1 = n;
    arrpr = new t[n1]; // agregar y crear memoria segun el n de elementos
    top = nullptr;
}
template<class t, int n>
pila<t, n>::~pila() {
    delete [] arrpr;
}
template<class t, int n>
bool pila<t, n>::lleno() {
    return top == arrpr + (n1 - 1);
}
template<class t, int n>
bool pila<t, n>::vacio() {
    return top == nullptr; // !top (false)
}
template<class t, int n>
bool pila<t, n>::push(t val) {
    if (vacio()) {
        top = arrpr;
    }
    else{
        if (lleno()) {
            return false;
        }
        else {
            top++;

        }
        *top = val;
        return true;
    }
}
template<class t, int n>
bool pila<t, n>::pop(t &val) {
    if (vacio()) {
        return false;
    }
    val = *top;
    top--;
    if (top < arrpr) {
        top = nullptr;

    }
    return true;

}

int main()
{
    pila <int, 20> p_Int;
    pila< char> pchar;
    if (p_Int.push(10))
        cout << "Ingreso 10:";
    else
        cout << "Falto ingresar 10";
    pchar.push('b');
    char x;
    pchar.pop(x);


}