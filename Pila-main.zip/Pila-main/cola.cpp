#include <iostream>
using namespace std;

class Cola {
private:
    int* A;
    int* frente;
    int* final;

public:
    Cola(int* arreglo) {
        A = arreglo;
        frente = final = A;
    }

    void push(int valor) {
        if (final < A + 10) {
            *final = valor;
            final++;
        } else {
            cout << "Cola llena\n";
        }
    }

    int pop() {
        if (frente < final) {
            int valor = *frente;
            frente++;
            return valor;
        } else {
            cout << "Nadota\n";
            return -1;
        }
    }

    void mostrar() {
        int* p = frente;
        cout << "Cola:" << endl;
        while (p < final) {
            cout << "[" << *p << "]" << endl;
            p++;
        }
        cout << endl;
    }
};

int main() {
    int arreglo[10];
    Cola c(arreglo);
    int datos[10] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    int* p = datos;
    while (p < datos + 10) {
        c.push(*p);
        p++;
    }

    c.mostrar();

    c.push(101); // Cola llena
    int valor;
    while (true) {
        valor = c.pop();
        if (valor == -1) break;
        cout << "Pop: " << valor << endl;
    }

    return 0;
}