#include <iostream>
using namespace std;

class Pila {
public:
    int* A;
    int* Top = nullptr;

    Pila(int* arreglo) {
        A = arreglo;
        Top = A;
    }

    void push(int valor) {
        if (Top < A + 10) {
            *Top = valor;
            Top++;
        } else {
            cout << "Ta ocupao" << endl;
        }
    }

    int pop() {
        if (Top > A) {
            Top--;
            cout << "Se esta borrando:" << *Top << endl;
            return *Top;
        } else {
            cout << endl << "Too borrao";
            return -1;
        }
    }

    void mostrar() {
        cout << "Pila:" << endl;
        for (int* p = Top; p > A; ) {
            p--;
            cout << "[" << *p << "]" << endl;
        }
        cout << endl;
    }
};

int main() {
    int arr[10];
    Pila p(arr);

    int valores[10] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    for (int* ptr = valores; ptr < valores + 10; ptr++) {
        p.push(*ptr);
    }

    p.mostrar();

    p.push(110); // Ta ocupao

    int val;
    while (true) {
        val = p.pop();
        if (val == -1) break;
        cout << "Pop: " << val << endl;
    }

    return 0;
}