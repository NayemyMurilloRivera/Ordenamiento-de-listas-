#include <iostream>
using namespace std;
template<class t, int n = 10>

struct cola{
    int n_elementos;
    t* arrpr;
    t* head;
    t* tail;

    cola();
    ~cola();
    bool lleno();
    bool vacio();
    bool push(t val);
    bool pop(t& val);
};

template<class t, int n>
cola<t, n>::cola() {
    n_elementos = n;
    arrpr = new t[n_elementos]; // agregar y crear memoria segun el n de elementos
    head = nullptr;
    tail = nullptr;

}

template<class t, int n>
cola<t, n>::~cola() {
    delete[] arrpr;
}

template<class t, int n>
bool cola<t, n>::lleno() {
    return tail == arrpr + (n_elementos - 1);
}

template<class t, int n>
bool cola<t, n>::vacio() {
    return (tail == nullptr) || (head == nullptr); // !top (false) # por probar
}

template<class t, int n>
bool cola<t, n>::push(t val) {
    if (vacio()) {
        head = arrpr;
        tail = arrpr;

    }
    else {
        if (lleno()){
            return true;
        }
        else {
            tail++;

        }
    *tail = val;
    return true;
}
}

template<class t, int n>
bool cola<t, n>::pop(t& val) {
    if (vacio()) {
        return false;
    }
    val = *head;
    head++;


#
    if (head < tail) {
        tail = arrpr;

    }
    else{
        head = arrpr;


    }

    return true;

}

int main()
{
    cola <int, 20> p_Int;
    if (p_Int.push(1))
        cout << " 1 ";
    else
        cout << "Falto ingresar";
    if (p_Int.push(2))
        cout << " 2 ";
    else
        cout << "Falto ingresar";



}
